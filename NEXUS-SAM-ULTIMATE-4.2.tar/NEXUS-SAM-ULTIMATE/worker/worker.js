/* NEXUS SAM Edge Router 4.2.0
 * Fixed public-provider allow-list. This is intentionally NOT an open proxy.
 * Set ALLOWED_ORIGIN in Wrangler vars for production; keep API keys in Worker secrets.
 */
const BASE_HEADERS = {
  'access-control-allow-methods': 'GET,OPTIONS',
  'access-control-allow-headers': 'Content-Type',
  'access-control-max-age': '86400',
  'content-type': 'application/json; charset=utf-8',
  'vary': 'Origin',
  'x-content-type-options': 'nosniff',
  'referrer-policy': 'no-referrer',
  'cache-control': 'no-store'
};
const json = (data, status = 200, extra = {}) => new Response(JSON.stringify(data), {
  status, headers: { ...BASE_HEADERS, ...extra }
});
const enc = value => encodeURIComponent(String(value || '').trim().slice(0, 180));
const PIPED = ['https://pipedapi.kavin.rocks', 'https://pipedapi.adminforge.de', 'https://pipedapi.r4fo.com'];
const INVIDIOUS = ['https://inv.nadeko.net', 'https://invidious.nerdvpn.de', 'https://invidious.privacyredirect.com'];
const PEERTUBE = ['https://diode.zone', 'https://tilvids.com'];
const SOURCES = [
  { id: 'ddg-web', kind: 'web', name: 'DuckDuckGo Instant Answers', url: q => `https://api.duckduckgo.com/?q=${q}&format=json&no_html=1&no_redirect=1` },
  { id: 'openverse', kind: 'image', name: 'Openverse', url: q => `https://api.openverse.org/v1/images/?q=${q}&page_size=24` },
  { id: 'commons', kind: 'image', name: 'Wikimedia Commons', url: q => `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=${q}&gsrnamespace=6&gsrlimit=24&prop=imageinfo&iiprop=url%7Cextmetadata&iiurlwidth=640&format=json&origin=*` },
  { id: 'piped-video', kind: 'video', name: 'Piped public instances', url: q => `${PIPED[0]}/search?q=${q}&filter=videos` },
  { id: 'invidious-video', kind: 'video', name: 'Invidious public instances', url: q => `${INVIDIOUS[0]}/api/v1/search?q=${q}&type=video` },
  { id: 'peertube-video', kind: 'video', name: 'PeerTube public instances', url: q => `${PEERTUBE[0]}/api/v1/search/videos?search=${q}&count=20` },
  { id: 'archive-video', kind: 'video', name: 'Internet Archive Video', url: q => `https://archive.org/advancedsearch.php?q=${q}%20AND%20mediatype:movies&fl[]=identifier,title,description&rows=24&page=1&output=json` },
  { id: 'archive-audio', kind: 'audio', name: 'Internet Archive Audio', url: q => `https://archive.org/advancedsearch.php?q=${q}%20AND%20mediatype:audio&fl[]=identifier,title,description&rows=20&output=json` },
  { id: 'crossref', kind: 'academic', name: 'Crossref', url: q => `https://api.crossref.org/works?query=${q}&rows=20` },
  { id: 'openalex', kind: 'academic', name: 'OpenAlex', url: q => `https://api.openalex.org/works?search=${q}&per-page=20` },
  { id: 'openlibrary', kind: 'books', name: 'Open Library', url: q => `https://openlibrary.org/search.json?q=${q}&limit=20` },
  { id: 'wikipedia', kind: 'knowledge', name: 'Wikipedia', url: (q, r, l) => `https://${l === 'fa' ? 'fa' : 'en'}.wikipedia.org/w/api.php?action=query&list=search&srsearch=${q}&srlimit=15&format=json&origin=*` },
  { id: 'wikidata', kind: 'knowledge', name: 'Wikidata', url: q => `https://www.wikidata.org/w/api.php?action=wbsearchentities&search=${q}&language=en&format=json&origin=*` },
  { id: 'gnews', kind: 'news', name: 'Google News RSS', url: (q, r, l) => `https://news.google.com/rss/search?q=${q}&hl=${l}-${r}&gl=${r}&ceid=${r}:${l}` },
  { id: 'itunes', kind: 'audio', name: 'Apple Podcasts', url: q => `https://itunes.apple.com/search?term=${q}&entity=podcast&limit=16` },
  { id: 'gutendex', kind: 'books', name: 'Gutendex / Project Gutenberg', url: q => `https://gutendex.com/books/?search=${q}` },
  { id: 'met', kind: 'image', name: 'The Met Collection', url: q => `https://collectionapi.metmuseum.org/public/collection/v1/search?q=${q}&hasImages=true` },
  { id: 'artic', kind: 'image', name: 'Art Institute Chicago', url: q => `https://api.artic.edu/api/v1/artworks/search?q=${q}&limit=15&fields=id,title,image_id,artist_title` },
  { id: 'nasa', kind: 'image', name: 'NASA Image Library', url: q => `https://images-api.nasa.gov/search?q=${q}&media_type=image` },
  { id: 'openalex-concepts', kind: 'academic', name: 'OpenAlex Concepts', url: q => `https://api.openalex.org/concepts?search=${q}&per-page=12` },
  { id: 'arxiv', kind: 'academic', name: 'arXiv API', url: q => `https://export.arxiv.org/api/query?search_query=all:${q}&start=0&max_results=12` },
  { id: 'gdelt', kind: 'news', name: 'GDELT DOC API', url: q => `https://api.gdeltproject.org/api/v2/doc/doc?query=${q}&mode=ArtList&format=json&maxrecords=15` }
];
const CATALOGS = [
  { name: 'Public APIs Directory', url: 'https://github.com/public-apis/public-apis', description: 'فهرست جامعه‌محور APIهای عمومی؛ نیازمند بررسی مجوز، وضعیت و محدودیت نرخ.' },
  { name: 'APIs.guru OpenAPI Directory', url: 'https://apis.guru/browse-apis/', description: 'کاتالوگ مستندات OpenAPI و مشخصات سرویس‌ها.' },
  { name: 'Postman API Network', url: 'https://www.postman.com/explore', description: 'کاتالوگ و مجموعه‌های API؛ بعضی نیازمند حساب یا کلید هستند.' },
  { name: 'RapidAPI Hub', url: 'https://rapidapi.com/hub', description: 'بازار API؛ بسیاری از سرویس‌ها تجاری و نیازمند مجوز هستند.' },
  { name: 'GitHub API topic', url: 'https://github.com/topics/public-api', description: 'مخازن عمومی مرتبط با API.' },
  { name: 'OpenAPI Initiative', url: 'https://www.openapis.org/', description: 'استاندارد توصیف API.' }
];
const ALLOWED_HOSTS = new Set([
  'api.duckduckgo.com', 'api.openverse.org', 'commons.wikimedia.org', 'archive.org',
  'api.crossref.org', 'api.openalex.org', 'openlibrary.org', 'en.wikipedia.org', 'fa.wikipedia.org',
  'www.wikidata.org', 'news.google.com', 'itunes.apple.com', 'gutendex.com',
  'collectionapi.metmuseum.org', 'api.artic.edu', 'images-api.nasa.gov', 'api.gdeltproject.org',
  'export.arxiv.org', 'pipedapi.kavin.rocks', 'pipedapi.adminforge.de', 'pipedapi.r4fo.com',
  'inv.nadeko.net', 'invidious.nerdvpn.de', 'invidious.privacyredirect.com', 'diode.zone', 'tilvids.com'
]);
const KINDS = new Set(['all', 'web', 'image', 'video', 'audio', 'academic', 'books', 'knowledge', 'news']);
function headersFor(request, env) {
  const origin = request.headers.get('Origin');
  const allowed = String(env.ALLOWED_ORIGIN || '').trim();
  const headers = { ...BASE_HEADERS };
  if (allowed) {
    if (origin === allowed) headers['access-control-allow-origin'] = allowed;
  } else {
    // Development default. Set ALLOWED_ORIGIN before public production deployment.
    headers['access-control-allow-origin'] = '*';
  }
  return headers;
}
function response(data, request, env, status = 200, extra = {}) {
  return new Response(JSON.stringify(data), { status, headers: { ...headersFor(request, env), ...extra } });
}
function parseRSS(raw) {
  const items = [];
  const blocks = raw.match(/<item\b[\s\S]*?<\/item>/gi) || [];
  const decode = value => String(value || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
  for (const block of blocks.slice(0, 20)) {
    const field = key => (block.match(new RegExp(`<${key}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${key}>`, 'i')) || [])[1] || '';
    items.push({ title: decode(field('title')), link: decode(field('link')), description: decode(field('description')).slice(0, 500) });
  }
  return { items };
}
async function fetchBounded(url, timeoutMs = 6500) {
  const parsed = new URL(url);
  if (parsed.protocol !== 'https:' || !ALLOWED_HOSTS.has(parsed.hostname)) throw new Error('host_not_allowlisted');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort('upstream_timeout'), timeoutMs);
  try {
    const res = await fetch(parsed, { signal: controller.signal, headers: { accept: 'application/json,application/atom+xml,application/rss+xml,text/xml,*/*' } });
    if (!res.ok) throw new Error(`upstream_${res.status}`);
    const length = Number(res.headers.get('content-length') || 0);
    if (length > 1_500_000) throw new Error('upstream_response_too_large');
    const text = await res.text();
    if (text.length > 1_500_000) throw new Error('upstream_response_too_large');
    return text;
  } finally { clearTimeout(timer); }
}
async function oneSource(source, query, region, language) {
  const started = Date.now();
  let urls;
  if (source.id === 'piped-video') urls = PIPED.map(host => `${host}/search?q=${query}&filter=videos`);
  else if (source.id === 'invidious-video') urls = INVIDIOUS.map(host => `${host}/api/v1/search?q=${query}&type=video`);
  else if (source.id === 'peertube-video') urls = PEERTUBE.map(host => `${host}/api/v1/search/videos?search=${query}&count=20`);
  else urls = [source.url(query, region, language)];
  let lastError = 'upstream_unavailable';
  for (let index = 0; index < urls.length; index++) {
    try {
      const raw = await fetchBounded(urls[index]);
      let data;
      try { data = JSON.parse(raw); } catch { data = source.id === 'gnews' ? parseRSS(raw) : { raw: raw.slice(0, 50000) }; }
      return { id: source.id, kind: source.kind, name: source.name, ok: true, ms: Date.now() - started, endpoint: new URL(urls[index]).host, data };
    } catch (error) {
      lastError = String(error?.message || 'upstream_failed').slice(0, 100);
      if (!/^upstream_(429|5\d\d)$/.test(lastError) && !['upstream_timeout', 'fetch failed'].includes(lastError)) break;
      if (index < urls.length - 1) await new Promise(resolve => setTimeout(resolve, 120 * (index + 1)));
    }
  }
  return { id: source.id, kind: source.kind, name: source.name, ok: false, ms: Date.now() - started, error: lastError };
}
async function discover() {
  const candidates = CATALOGS.map((item, index) => ({ ...item, id: `catalog-${index + 1}`, kind: 'catalog', requiresReview: true }));
  try {
    const raw = await fetch('https://raw.githubusercontent.com/public-apis/public-apis/master/README.md', { headers: { accept: 'text/plain' }, signal: AbortSignal.timeout(6000) });
    if (raw.ok) {
      const markdown = await raw.text(); let category = 'General';
      for (const line of markdown.split(/\r?\n/)) {
        const heading = line.match(/^#{2,3}\s+(.+)/); if (heading) { category = heading[1].trim(); continue; }
        const match = line.match(/^\|\s*\[([^\]]+)\]\((https?:\/\/[^)]+)\)\s*\|\s*([^|]+)\|/);
        if (match && candidates.length < 50) candidates.push({ id: `candidate-${candidates.length + 1}`, name: match[1], url: match[2], description: match[3].trim(), category, kind: 'public-api-candidate', requiresReview: true });
        if (candidates.length >= 50) break;
      }
    }
  } catch { /* catalogue unavailable; curated directory remains useful */ }
  if (candidates.length < 50) {
    try {
      const directory = await fetch('https://api.apis.guru/v2/list.json', { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(6000) });
      if (directory.ok) {
        const data = await directory.json();
        for (const [id, entry] of Object.entries(data)) {
          if (candidates.length >= 50) break;
          const preferred = entry.preferred;
          const version = preferred ? entry.versions?.[preferred] : null;
          const spec = version?.swaggerUrl || version?.openapiUrl;
          if (spec) candidates.push({ id: `openapi-${candidates.length + 1}`, name: version.info?.title || id, url: spec, description: (version.info?.description || 'OpenAPI metadata candidate').slice(0, 350), kind: 'openapi-candidate', requiresReview: true });
        }
      }
    } catch { /* OpenAPI index may be temporarily unavailable */ }
  }
  return { count: candidates.length, candidates, policy: 'Metadata only: candidates are not executed. Review terms, authentication, CORS, quotas and privacy before integration.', checkedAt: new Date().toISOString() };
}
async function health() {
  const checks = await Promise.all(SOURCES.map(async source => {
    const result = await oneSource(source, enc('nexus'), 'US', 'en');
    return { id: result.id, name: result.name, ok: result.ok, ms: result.ms, ...(result.error ? { error: result.error } : {}) };
  }));
  return { checked: checks.length, healthy: checks.filter(item => item.ok).length, results: checks, at: new Date().toISOString() };
}
export default {
  async fetch(request, env = {}, ctx = { waitUntil: () => {} }) {
    const url = new URL(request.url);
    const allowedOrigin = String(env.ALLOWED_ORIGIN || '').trim();
    const origin = request.headers.get('Origin');
    if (allowedOrigin && origin && origin !== allowedOrigin) return response({ error: 'origin_not_allowed' }, request, env, 403);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: headersFor(request, env) });
    if (request.method !== 'GET') return response({ error: 'method_not_allowed' }, request, env, 405);
    if (url.pathname === '/health') return response({ ok: true, name: 'NEXUS SAM Edge Router', version: '4.2.0', sources: SOURCES.length, time: new Date().toISOString() }, request, env, 200, { 'cache-control': 'no-store' });
    if (url.pathname === '/api/sources') return response({ count: SOURCES.length, sources: SOURCES.map(({ id, kind, name }) => ({ id, kind, name, mode: 'public API', auth: 'provider dependent' })) }, request, env);
    if (url.pathname === '/api/catalog') return response({ count: CATALOGS.length, candidates: CATALOGS, notice: 'Catalog links only; not all APIs are free or unauthenticated.' }, request, env);
    if (url.pathname === '/api/discover') return response(await discover(), request, env, 200, { 'cache-control': 'public,max-age=1800' });
    if (url.pathname === '/api/check') return response(await health(), request, env, 200, { 'cache-control': 'no-store' });
    if (url.pathname === '/api/search') {
      const query = (url.searchParams.get('q') || '').trim();
      if (!query) return response({ error: 'query_required' }, request, env, 400);
      if (query.length > 180) return response({ error: 'query_too_long' }, request, env, 400);
      const kind = url.searchParams.get('kind') || 'all';
      if (!KINDS.has(kind)) return response({ error: 'unsupported_kind' }, request, env, 400);
      const region = (url.searchParams.get('region') || 'US').toUpperCase().slice(0, 2);
      const language = (url.searchParams.get('lang') || 'en').slice(0, 5);
      const network = (url.searchParams.get('network') || 'auto').slice(0, 12);
      const cache = typeof caches !== 'undefined' ? caches.default : null;
      const cacheKey = new Request(url.toString(), { method: 'GET' });
      if (cache) { const hit = await cache.match(cacheKey); if (hit) return hit; }
      const sources = SOURCES.filter(source => kind === 'all' || source.kind === kind);
      const results = await Promise.all(sources.map(source => oneSource(source, enc(query), region, language)));
      const body = { query, kind, region, language, network, results, successful: results.filter(item => item.ok).length, failed: results.filter(item => !item.ok).length, notice: 'Region and network profiles affect provider parameters or ordering only; they do not change the client IP or bypass ISP restrictions.' };
      const output = response(body, request, env, 200, { 'cache-control': 'public,max-age=30' });
      if (cache) ctx.waitUntil(cache.put(cacheKey, output.clone()));
      return output;
    }
    return response({ error: 'not_found', routes: ['/health', '/api/sources', '/api/catalog', '/api/discover', '/api/check', '/api/search?q=term&kind=web|image|video|audio|academic|books|knowledge|news|all'] }, request, env, 404);
  }
};
