/* NEXUS SAM offline shell cache 4.2.0 */
const CACHE='nexus-sam-shell-v42';
const CORE=['./','./index.html','./styles.css','./app.js','./manifest.webmanifest','./assets/icons/nexus.svg','./assets/fonts/NotoSansArabic-Regular.ttf','./assets/fonts/NotoSansArabic-Bold.ttf','./assets/fonts/NotoSansArabicUI-Regular.ttf','./assets/fonts/NotoSansArabicUI-Bold.ttf','./assets/fonts/NotoSansArabic-SemiBold.ttf','./assets/fonts/Inter-Regular.otf','./assets/fonts/Inter-Bold.otf'];
self.addEventListener('install',event=>event.waitUntil((async()=>{const cache=await caches.open(CACHE);await cache.addAll(CORE);await self.skipWaiting();})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{const keys=await caches.keys();await Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key)));await self.clients.claim();})()));
self.addEventListener('fetch',event=>{
 const request=event.request,url=new URL(request.url);
 if(request.method!=='GET'||url.origin!==self.location.origin)return;
 if(request.mode==='navigate'){
  event.respondWith((async()=>{try{const fresh=await fetch(request);if(fresh.ok){const cache=await caches.open(CACHE);cache.put('./index.html',fresh.clone());}return fresh;}catch{return (await caches.match(request))||(await caches.match('./index.html'));}})());
  return;
 }
 event.respondWith((async()=>{const cached=await caches.match(request);if(cached)return cached;try{const fresh=await fetch(request);if(fresh.ok){const cache=await caches.open(CACHE);cache.put(request,fresh.clone());}return fresh;}catch{return cached||Response.error();}})());
});
