#!/usr/bin/env python3
"""NEXUS API Scout — discover public API metadata without executing unknown APIs.

Usage:
  python tools/discover_apis.py --limit 40 --output api-candidates.json

The scout reads the public-apis community directory and a public OpenAPI index.
It does NOT harvest credentials, bypass auth, or invoke arbitrary API endpoints.
"""
from __future__ import annotations
import argparse, json, re, sys, time
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from pathlib import Path

PUBLIC_APIS_README = "https://raw.githubusercontent.com/public-apis/public-apis/master/README.md"
APIS_GURU_INDEX = "https://api.apis.guru/v2/list.json"
UA = "NEXUS-SAM-API-Scout/4.0 (metadata-only; contact: local-admin)"

def get(url: str, timeout: int = 12):
    req = Request(url, headers={"User-Agent": UA, "Accept": "application/json,text/plain,*/*"})
    with urlopen(req, timeout=timeout) as response:
        return response.read()

def parse_public_apis(markdown: str, limit: int):
    found, category = [], "General"
    for line in markdown.splitlines():
        heading = re.match(r"^#{2,3}\s+(.+)", line)
        if heading:
            category = heading.group(1).strip()
            continue
        row = re.match(r"^\|\s*\[([^\]]+)\]\((https?://[^)]+)\)\s*\|\s*([^|]+)\|", line)
        if row:
            name, url, auth = (x.strip() for x in row.groups())
            found.append({"name": name, "url": url, "category": category,
                          "auth_note": auth, "source": "public-apis/public-apis",
                          "status": "candidate-needs-review"})
            if len(found) >= limit:
                break
    return found

def parse_apis_guru(raw: bytes, limit: int):
    data = json.loads(raw.decode("utf-8"))
    found = []
    for name, item in data.items():
        preferred = item.get("preferred")
        version = item.get("versions", {}).get(preferred, {}) if preferred else {}
        url = version.get("swaggerUrl") or version.get("openapiUrl")
        if not url:
            continue
        info = version.get("info", {})
        found.append({"name": info.get("title") or name, "url": url,
                      "description": info.get("description", "")[:400],
                      "source": "apis.guru", "status": "openapi-metadata-only"})
        if len(found) >= limit:
            break
    return found

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--limit", type=int, default=30, choices=range(10, 51))
    parser.add_argument("--output", default="api-candidates.json")
    args = parser.parse_args()
    all_items, errors = [], []
    for label, url, parser_fn in [
        ("public-apis", PUBLIC_APIS_README, lambda b: parse_public_apis(b.decode("utf-8", "replace"), args.limit)),
        ("apis-guru", APIS_GURU_INDEX, lambda b: parse_apis_guru(b, args.limit)),
    ]:
        try:
            all_items.extend(parser_fn(get(url)))
            print(f"[OK] {label}: metadata received", file=sys.stderr)
        except (URLError, HTTPError, TimeoutError, ValueError, KeyError) as exc:
            errors.append({"catalog": label, "error": str(exc)[:240]})
            print(f"[WARN] {label}: {exc}", file=sys.stderr)
        time.sleep(0.35)
    # De-duplicate by normalized URL and cap the result count.
    unique, seen = [], set()
    for item in all_items:
        key = item.get("url", "").rstrip("/").lower()
        if key and key not in seen:
            seen.add(key); unique.append(item)
        if len(unique) >= args.limit:
            break
    output = {"generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
              "count": len(unique), "candidates": unique, "catalog_errors": errors,
              "safety": "Metadata discovery only. Review terms, authentication, rate limits, privacy and CORS before integration. No unknown API is executed."}
    path = Path(args.output)
    path.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Saved {len(unique)} candidates to {path}")
    return 0 if unique else 2

if __name__ == "__main__":
    raise SystemExit(main())
