# NEXUS Architecture Notes — 4.2

## Request flow

1. Browser classifies a query by content category.
2. Direct provider routes are generated as fallbacks. They open the provider's own search page; they are not scraped or represented as inline results.
3. If a Worker URL is configured, the browser requests the fixed `/api/search` endpoint.
4. Worker fans out to a fixed allow-list of public APIs with per-provider timeout.
5. Results are normalized, merged and deduplicated in the browser.
6. Image previews use provider thumbnails; media playback is attempted only for direct media URLs or supported embeds.

## Reliability strategy

- Multiple independent search engines are exposed for each category.
- Piped and Invidious use a small rotating fallback pool; instances can disappear or rate-limit.
- A failed upstream is reported independently; it does not fail the whole search response.
- The Worker has no arbitrary `?url=` proxy parameter.
- Provider region and language values affect search metadata only.

## API discovery safety

The API Scout reads curated public directories and OpenAPI metadata. It does not execute newly discovered endpoints. Automated execution of unknown APIs could leak query data, trigger billing, violate terms, or expose credentials. A human must approve an adapter before it is added to the allow-list.


## نسخه 4.1: شبکه و نمایش رسانه
- UI یک پروفایل شبکه دارد: auto، national-first و global-first. این فقط ترتیب منابع/پارامترهای منطقه را عوض می‌کند و IP را تغییر نمی‌دهد.
- در پروفایل ملی، لینک‌های جست‌وجوی مستقیم ایرنا، ایسنا، مهر، تسنیم، فارس و ورزش۳ در ابتدای نتایج قرار می‌گیرند. هیچ دسترسی از قبل تضمین نشده است.
- Worker جست‌وجوی فوری DuckDuckGo را برای خلاصه/موضوعات ارائه می‌کند؛ برای ایندکس کامل وب، لینک‌های موتورهای جست‌وجو استفاده می‌شوند.
- نمایشگر تصویر زوم و لینک منبع دارد. پلیر فایل مستقیم MP4/WebM/OGG سرعت پخش و Picture-in-Picture دارد.
- API Scout فقط فرادادهٔ APIها را از کاتالوگ‌های عمومی کشف می‌کند. API ناشناخته را خودکار اجرا نمی‌کند تا از SSRF، افشای کلید و اجرای endpointهای ناامن جلوگیری شود.


## Version 4.2 hardening
- Provider responses are limited to 1.5 MB and each upstream request has a bounded timeout.
- Piped, Invidious and PeerTube use a small fixed instance pool; only those hosts are allowed.
- Worker CORS can be restricted with `ALLOWED_ORIGIN`; configure the exact GitHub Pages origin before public deployment.
- Browser result links and thumbnails accept HTTP(S) only. Worker URLs are validated before use.
- The API Scout remains metadata-only; it never executes discovered endpoints.
