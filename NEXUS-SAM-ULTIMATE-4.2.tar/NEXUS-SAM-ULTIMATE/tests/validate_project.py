#!/usr/bin/env python3
"""Static integrity checks for the NEXUS SAM project."""
from pathlib import Path
import json, re, sys
ROOT = Path(__file__).resolve().parents[1]
errors = []
for rel in ['index.html','styles.css','app.js','sw.js','manifest.webmanifest','worker/worker.js','config/api-registry.json','tools/discover_apis.py']:
    if not (ROOT / rel).is_file() or (ROOT / rel).stat().st_size == 0:
        errors.append(f'missing/empty required file: {rel}')
html = (ROOT/'index.html').read_text(encoding='utf-8')
js = (ROOT/'app.js').read_text(encoding='utf-8')
ids = set(re.findall(r'id="([^"]+)"', html))
refs = set(re.findall(r"\$\('#([^']+)'\)", js)) | set(re.findall(r'\$\("#([^\"]+)"\)', js))
missing = sorted(refs - ids)
# Optional UI hooks may be guarded by a null check; currently networkBadge is optional.
missing = [item for item in missing if item != 'networkBadge']
if missing: errors.append('JS references missing HTML IDs: ' + ', '.join(missing))
registry = json.loads((ROOT/'config/api-registry.json').read_text(encoding='utf-8'))
worker = (ROOT/'worker/worker.js').read_text(encoding='utf-8')
source_count = len(re.findall(r"\{ id: '[a-z0-9-]+', kind:", worker))
if source_count != 22: errors.append(f'expected 22 Worker source adapters, found {source_count}')
api_adapters = [item for item in registry.get('sources', []) if item.get('adapter') != 'metadata-discovery']
if len(api_adapters) != 22: errors.append(f'expected 22 API registry adapters, found {len(api_adapters)}')
if not any(item.get('id') == 'peertube' for item in registry['sources']): errors.append('PeerTube registry adapter missing')
manifest = json.loads((ROOT/'manifest.webmanifest').read_text(encoding='utf-8'))
for asset in re.findall(r"'\./([^']+)'", (ROOT/'sw.js').read_text(encoding='utf-8')):
    if asset.startswith('assets/') and not (ROOT/asset).exists(): errors.append(f'Service Worker precache asset missing: {asset}')
if 'function safeHttpUrl' not in js: errors.append('safe HTTP(S) result URL validation missing')
if 'u.pathname=path' not in js: errors.append('Worker route construction check missing')
if errors:
    print('\n'.join('FAIL: '+error for error in errors), file=sys.stderr)
    raise SystemExit(1)
print(f'Project integrity checks passed: {len(ids)} HTML IDs, {source_count} Worker APIs, {len(api_adapters)} registry adapters.')
