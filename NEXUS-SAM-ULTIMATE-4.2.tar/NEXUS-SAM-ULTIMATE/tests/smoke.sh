#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
test -s "$ROOT/index.html"
test -s "$ROOT/styles.css"
test -s "$ROOT/app.js"
test -s "$ROOT/worker/worker.js"
test -s "$ROOT/tools/discover_apis.py"
python -m py_compile "$ROOT/tools/discover_apis.py"
python "$ROOT/tests/validate_project.py"
if command -v node >/dev/null 2>&1; then
  node --check "$ROOT/app.js"
  node --check "$ROOT/worker/worker.js"
  node "$ROOT/tests/worker.test.mjs"
  node "$ROOT/tests/engine-count.test.mjs"
fi
printf '%s\n' 'NEXUS smoke checks passed.'
