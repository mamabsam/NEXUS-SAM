import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const source = await readFile(new URL('../worker/worker.js', import.meta.url), 'utf8');
const moduleUrl = `data:text/javascript;base64,${Buffer.from(source).toString('base64')}`;
const { default: worker } = await import(moduleUrl);
const ctx = { waitUntil(promise) { Promise.resolve(promise).catch(() => {}); } };
const call = (path, init = {}, env = {}) => worker.fetch(new Request(`https://nexus.test${path}`, init), env, ctx);

let response = await call('/health');
assert.equal(response.status, 200);
let data = await response.json();
assert.equal(data.ok, true);
assert.equal(data.version, '4.2.0');
assert.equal(data.sources, 22);

response = await call('/api/sources');
data = await response.json();
assert.equal(data.count, 22);
assert.equal(data.sources.length, 22);
assert.ok(data.sources.some(item => item.id === 'peertube-video'));

response = await call('/api/search');
assert.equal(response.status, 400);
assert.equal((await response.json()).error, 'query_required');

response = await call('/api/search?q=test&kind=not-a-kind');
assert.equal(response.status, 400);
assert.equal((await response.json()).error, 'unsupported_kind');

response = await call('/api/search?q=' + 'x'.repeat(181));
assert.equal(response.status, 400);
assert.equal((await response.json()).error, 'query_too_long');

response = await call('/health', { method: 'POST' });
assert.equal(response.status, 405);

response = await call('/health', { headers: { Origin: 'https://evil.example' } }, { ALLOWED_ORIGIN: 'https://sam.github.io' });
assert.equal(response.status, 403);

response = await call('/health', { headers: { Origin: 'https://sam.github.io' } }, { ALLOWED_ORIGIN: 'https://sam.github.io' });
assert.equal(response.status, 200);
assert.equal(response.headers.get('access-control-allow-origin'), 'https://sam.github.io');


const originalFetch = globalThis.fetch;
let upstreamHost = '';
globalThis.fetch = async input => {
  upstreamHost = new URL(input).hostname;
  return new Response(JSON.stringify({ AbstractText: 'A short test answer', AbstractURL: 'https://example.org/article', RelatedTopics: [] }), { status: 200, headers: { 'content-type': 'application/json' } });
};
response = await call('/api/search?q=sample&kind=web&url=https://attacker.example');
data = await response.json();
assert.equal(response.status, 200);
assert.equal(data.successful, 1);
assert.equal(data.results[0].ok, true);
assert.equal(upstreamHost, 'api.duckduckgo.com');
globalThis.fetch = originalFetch;

console.log('Worker route, validation, source-count, allow-list and CORS tests passed.');
